/// <reference path="index.d.ts"/>

declare module 'connected-react-router/seamless-immutable' {

    export * from 'connected-react-router';
}
