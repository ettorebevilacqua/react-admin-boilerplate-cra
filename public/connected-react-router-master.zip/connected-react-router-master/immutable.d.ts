/// <reference path="./index.d.ts"/>

declare module 'connected-react-router/immutable' {

  export * from 'connected-react-router';

}