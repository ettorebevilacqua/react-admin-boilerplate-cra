module.exports = require('./lib/seamless-immutable')
